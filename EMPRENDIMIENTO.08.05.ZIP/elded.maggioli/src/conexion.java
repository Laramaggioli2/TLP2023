
import com.mysql.jdbc.Connection;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author PC11
 */
public class conexion {
    Connection conectar=null;
    public Connection conectar() {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            conectar= (Connection) DriverManager.getConnection("jdbc:mysql://localhost/elded.maggioli","root",null);
            JOptionPane.showMessageDialog(null,"conexión exitosa","conexión", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (ClassNotFoundException | SQLException e){
            JOptionPane.showMessageDialog(null,"sin conexion"+e,"conexión", JOptionPane.ERROR_MESSAGE);
        }
        return conectar;
    }
}
